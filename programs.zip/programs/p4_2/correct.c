/* 
 * p4_2
 */

#include <stdio.h>
#include <math.h>

int main() {

  double a = 2.0;

  printf("log10(%d) = %f\n", a, log10(a));
  printf("log10(%f) = %f\n", a, log10(a));

  return 0;
  
}
