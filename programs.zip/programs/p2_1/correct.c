/* 
 * p2_1
 * 青山学院大学　青山花子
 */

#include <stdio.h>

int main()
{

  printf("青山学院大学\n");
  printf("\t青山太郎\n");

  return 0;
}
