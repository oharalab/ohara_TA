#include <stdio.h>

int main(){

   printf("学科名は\"学科\"\n");
   printf("名前は\"\"\n");

   return(0);

}
