/* 
 * p3_4
 */

#include <stdio.h>

int main() {
  int a;

  a = 10;
  printf("%d\n", a);
  printf("%d\n", a++);
  printf("%d\n", a);
  printf("%d\n", ++a);
  printf("%d\n", a--);
  printf("%d\n", --a);

  return 0;
}

