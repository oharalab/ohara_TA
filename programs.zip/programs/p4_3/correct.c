/*
* p4_3 整数値の読み込み
*/

#include <stdio.h>

int main() {

  int num;
  scanf("%d", &num);
  printf("%d\n", num);

  return 0;
  
}
