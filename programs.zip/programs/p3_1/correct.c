/* 
 * p3_1
 */

#include <stdio.h>

int main()
{
  int a, b, c;

  a = 10;
  b = 20;
  c = a + b;
  printf("%d\n", c);

  return 0;
}
