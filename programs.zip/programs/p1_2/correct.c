/* 
 * p1_2
 * 青山学院大学 青山花子
 */
#include <stdio.h>

int main() {

  printf("青山学院大学\n青山花子\n");

  return 0;
}
