/* 
 * p12_1
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(){

  char moji;
  printf("半角文字を入力してください\n");
  scanf("%c", &moji);
  printf("%c\n", moji);

  return(0);
} 
