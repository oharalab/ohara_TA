/* 
 * p2_2
 * 青山学院大学　青山花子
 */

#include <stdio.h>

int main()
{
  printf("1+2=3\n");
  printf("1+2=%d\n", 1+2);

  return 0;
}
