#include <stdio.h>

int main() {
  printf("5.0 / 3.0     =%-.3lf\n", 5.0/3.0);
  printf("2 + 3 * 4     =%4d\n", 2+3*4);
  printf("2.0 / 5.0 * 4 =%5.2lf\n", 2.0/5.0*4);

  return 0;
}
