/* 
 * p3_3
 * 実行不可
 */

#include <stdio.h>

int main() {

  int a, b, c;

  a = 10;
  b = 20;
  printf("%d, %d, %d", a, b, c);

  return 0;
}
