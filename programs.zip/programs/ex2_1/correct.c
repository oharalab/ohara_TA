#include <stdio.h>

int main() {

  printf("情報テクノロジー学科\n\n三國孔明");

  return 0;
}
