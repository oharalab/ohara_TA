/* p1_1 */
#include <stdio.h>

int main() {
  printf("青山学院大学\n");
  printf("青山花子\n");

  return 0;
}
