/* 
 * p12_2
 */

#include <stdio.h>

int main(){

  int ch;
  printf("半角文字を入力してください\n");
  ch = getchar();
  putchar(ch);

  return(0);
} 
