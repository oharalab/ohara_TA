/* 
 * p2_4
 * 青山学院大学　青山花子
 */

#include <stdio.h>

int main()
{
  double num = 123.456; 
  printf("桁数:%d\n",     123456789);
  printf("数値:%.6lf\n",  num);
  printf("数値:%9.3lf\n", num);
  printf("数値:%.4lf\n",  num);
  printf("数値:%9.1f\n",  num);

  return 0;
}
