/* 
 * p7_4b
 */

#include <stdio.h>

int main() {

  int i;
  for(i = 10; i > 0; i--){
    printf("%3d", i);
  }
  printf("\n");

  return(0);
}
