/* 
 * p2_3
 * 青山学院大学　青山花子
 */

#include <stdio.h>

int main()
{
  
  printf("10/2=%d\n", 10/3);
  printf("10/2=%f\n", 10.0/3.0);
  printf("10/2=%lf\n", 10.0/3.0);
  printf("7+1=%3d\n", 7+1);
  printf("7*9=%3d\n", 7*9);
  printf("7/3=%.3f\n", 7.0/3.0);

  return 0;
}
