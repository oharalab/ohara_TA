/* 
 * p5_1
 */

#include <stdio.h>

int main() {

  int a = 20;

  if (a > 10) {
    printf("a > 10\n");
  } else {
    printf("a <= 10\n");
  }

  return 0;
}

