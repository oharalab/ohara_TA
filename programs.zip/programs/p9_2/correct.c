/* 
 * p10_2
 */

#include<stdio.h>
#include<math.h>

int main(){

  printf("7 * 3 = %d\n", 7*3);
  printf("7 / 3 = %5.2f\n", 7.0 / 3.0);
  printf("7 の 3 乗：%.0f\n", pow(7.0,3.0));

  return 0;
}
