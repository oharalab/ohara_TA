#include <stdio.h>

int main() {

  printf("情報テクノロジー学科\n三國孔明\n");

  return 0;
}
